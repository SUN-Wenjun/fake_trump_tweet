Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USWNT",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616057454430957572",
  "text" : "Congrats to the #USWNT! Can't wait for the finals. You make us all proud!",
  "id" : 616057454430957572,
  "created_at" : "2015-07-01 01:35:17 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/MrV56vTNa9",
      "expanded_url" : "https:\/\/twitter.com\/huffpostpol\/status\/615858859178110976",
      "display_url" : "twitter.com\/huffpostpol\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615887901654675456",
  "text" : "A hard day's work deserves a fair day's pay. That's why I'm announcing my plan to extend overtime protections. https:\/\/t.co\/MrV56vTNa9",
  "id" : 615887901654675456,
  "created_at" : "2015-06-30 14:21:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/614552886731780097\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/jMS0SDUYui",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdUlXtUkAECHvI.jpg",
      "id_str" : "614552875155361793",
      "id" : 614552875155361793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdUlXtUkAECHvI.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jMS0SDUYui"
    } ],
    "hashtags" : [ {
      "text" : "HateWontWin",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614552886731780097",
  "text" : "So inspired by the grace shown by the Simmons family and all the victims' families in Charleston. #HateWontWin http:\/\/t.co\/jMS0SDUYui",
  "id" : 614552886731780097,
  "created_at" : "2015-06-26 21:56:40 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614435467120001024",
  "text" : "Today is a big step in our march toward equality. Gay and lesbian couples now have the right to marry, just like anyone else. #LoveWins",
  "id" : 614435467120001024,
  "created_at" : "2015-06-26 14:10:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614114880786956288",
  "geo" : { },
  "id_str" : "614119220440367105",
  "in_reply_to_user_id" : 1536791610,
  "text" : "The uninsured rate is the lowest it's ever been. Let's keep at it until every American has quality, affordable health insurance.",
  "id" : 614119220440367105,
  "in_reply_to_status_id" : 614114880786956288,
  "created_at" : "2015-06-25 17:13:26 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614111236620427265",
  "geo" : { },
  "id_str" : "614114880786956288",
  "in_reply_to_user_id" : 1536791610,
  "text" : "More than 137 million Americans have guaranteed access to preventive care like cancer screenings and birth control at no out-of-pocket cost.",
  "id" : 614114880786956288,
  "in_reply_to_status_id" : 614111236620427265,
  "created_at" : "2015-06-25 16:56:11 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614108370832891904",
  "geo" : { },
  "id_str" : "614111236620427265",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Women can no longer be charged more for health coverage just for being women.",
  "id" : 614111236620427265,
  "in_reply_to_status_id" : 614108370832891904,
  "created_at" : "2015-06-25 16:41:43 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614104506410901504",
  "geo" : { },
  "id_str" : "614108370832891904",
  "in_reply_to_user_id" : 1536791610,
  "text" : "129 million Americans with pre-existing conditions can no longer be denied health coverage.",
  "id" : 614108370832891904,
  "in_reply_to_status_id" : 614104506410901504,
  "created_at" : "2015-06-25 16:30:19 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614101662349848576",
  "geo" : { },
  "id_str" : "614104506410901504",
  "in_reply_to_user_id" : 1536791610,
  "text" : "More than 16 million Americans have gained health coverage after 5 years of the Affordable Care Act.",
  "id" : 614104506410901504,
  "in_reply_to_status_id" : 614101662349848576,
  "created_at" : "2015-06-25 16:14:58 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614101662349848576",
  "text" : "Today's decision is a victory for every hardworking American. Access to quality, affordable health care is a right, not a privilege.",
  "id" : 614101662349848576,
  "created_at" : "2015-06-25 16:03:40 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/613130677303799809\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/btu3dRXPbr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
      "id_str" : "613130667912765440",
      "id" : 613130667912765440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      } ],
      "display_url" : "pic.twitter.com\/btu3dRXPbr"
    } ],
    "hashtags" : [ {
      "text" : "OneNationOneTeam",
      "indices" : [ 46, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613130677303799809",
  "text" : "Good luck Team USA \u2013 make us proud out there! #OneNationOneTeam http:\/\/t.co\/btu3dRXPbr",
  "id" : 613130677303799809,
  "created_at" : "2015-06-22 23:45:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612437042207834112",
  "geo" : { },
  "id_str" : "612437278019973120",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Expressions of sympathy aren\u2019t enough. It\u2019s time we do something about this.",
  "id" : 612437278019973120,
  "in_reply_to_status_id" : 612437042207834112,
  "created_at" : "2015-06-21 01:50:00 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612437042207834112",
  "text" : "Here are the stats: Per population, we kill each other with guns at a rate 297x more than Japan, 49x more than France, 33x more than Israel.",
  "id" : 612437042207834112,
  "created_at" : "2015-06-21 01:49:04 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/Ryusfp8Xbh",
      "expanded_url" : "https:\/\/www.twitter.com\/MittRomney\/status\/612276050182049792",
      "display_url" : "twitter.com\/MittRomney\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612433183297142784",
  "text" : "Good point, Mitt. https:\/\/t.co\/Ryusfp8Xbh",
  "id" : 612433183297142784,
  "created_at" : "2015-06-21 01:33:44 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/aYtAKrWwCY",
      "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/611972235079741441",
      "display_url" : "twitter.com\/ABC\/status\/611\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611993830980747265",
  "text" : "In the midst of darkest tragedy, the decency and goodness of the American people shines through in these families. https:\/\/t.co\/aYtAKrWwCY",
  "id" : 611993830980747265,
  "created_at" : "2015-06-19 20:27:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 17, 26 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611675003436843008",
  "text" : "Inspired by what @Pontifex wrote on climate change. Agree we have a moral responsibility to act to protect our kids and God's creation.",
  "id" : 611675003436843008,
  "created_at" : "2015-06-18 23:20:59 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 31, 44 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611227969030328321",
  "text" : "Thrilled to formally recognize @LorettaLynch as the people's lawyer. You'll have no better partner in the fight for equality and justice.",
  "id" : 611227969030328321,
  "created_at" : "2015-06-17 17:44:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611026361491324929",
  "text" : "What a team win for the Warriors and an epic season for Steph. Kudos to LeBron and the Cavs for an unbelievable effort under adversity.",
  "id" : 611026361491324929,
  "created_at" : "2015-06-17 04:23:31 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 24, 38 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610820023968514048",
  "text" : "Congrats to my hometown @NHLBlackhawks on 3 titles in 6 years - we'll see you and The Cup at the White House!",
  "id" : 610820023968514048,
  "created_at" : "2015-06-16 14:43:36 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/610536520387268608\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ao6k8ErjHI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkPuPKUsAAxT-W.jpg",
      "id_str" : "610536511503642624",
      "id" : 610536511503642624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkPuPKUsAAxT-W.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ao6k8ErjHI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610536520387268608",
  "text" : "So proud of these White House mentorship grads. Can't wait to see all the great things you achieve. I believe in you! http:\/\/t.co\/ao6k8ErjHI",
  "id" : 610536520387268608,
  "created_at" : "2015-06-15 19:57:04 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/609163576616615936\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/FpEUTnYgoD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
      "id_str" : "609163561982672896",
      "id" : 609163561982672896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FpEUTnYgoD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609163576616615936",
  "text" : "I challenged them to a race. http:\/\/t.co\/FpEUTnYgoD",
  "id" : 609163576616615936,
  "created_at" : "2015-06-12 01:01:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/606226830241046528\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/E2SeO9tumt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnAFtLVIAAVtOX.png",
      "id_str" : "606226829117038592",
      "id" : 606226829117038592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnAFtLVIAAVtOX.png",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 915,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 930,
        "resize" : "fit",
        "w" : 1041
      } ],
      "display_url" : "pic.twitter.com\/E2SeO9tumt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606226830241046528",
  "text" : "This was a fun briefing: My science advisor just showed me this Hubble shot of the most crowded place in our galaxy. http:\/\/t.co\/E2SeO9tumt",
  "id" : 606226830241046528,
  "created_at" : "2015-06-03 22:31:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605841647193030657",
  "text" : "Glad the Senate finally passed the USA Freedom Act. It protects civil liberties and our national security. I'll sign it as soon as I get it.",
  "id" : 605841647193030657,
  "created_at" : "2015-06-02 21:01:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/605803300093452289\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AYazTecZpB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGg-5BsUcAEV5S4.jpg",
      "id_str" : "605803299309121537",
      "id" : 605803299309121537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGg-5BsUcAEV5S4.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/AYazTecZpB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605803300093452289",
  "text" : "Awarded two Medals of Honor today for acts of bravery a century ago. We honor our heroes no matter how long it takes. http:\/\/t.co\/AYazTecZpB",
  "id" : 605803300093452289,
  "created_at" : "2015-06-02 18:28:56 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]