Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/J8A6mTD6D4",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "in_reply_to_status_id_str" : "648543480277544960",
  "geo" : { },
  "id_str" : "648544017806938112",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We have a moral responsibility to do what we can for families forced from their homes. Find out how you can help at http:\/\/t.co\/J8A6mTD6D4.",
  "id" : 648544017806938112,
  "in_reply_to_status_id" : 648543480277544960,
  "created_at" : "2015-09-28 17:05:17 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648543139196743680",
  "geo" : { },
  "id_str" : "648543480277544960",
  "in_reply_to_user_id" : 1536791610,
  "text" : "But this isn't just about what I can do as President. Every single one of us - from citizens to NGOs - can help refugees find safe haven.",
  "id" : 648543480277544960,
  "in_reply_to_status_id" : 648543139196743680,
  "created_at" : "2015-09-28 17:03:09 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648542721125294080",
  "geo" : { },
  "id_str" : "648543139196743680",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We're also increasing the number of Syrian and other refugees we admit to the U.S. to 100,000 per year for the next two years.",
  "id" : 648543139196743680,
  "in_reply_to_status_id" : 648542721125294080,
  "created_at" : "2015-09-28 17:01:48 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648542324167974917",
  "geo" : { },
  "id_str" : "648542721125294080",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We've provided more than $4.5 billion in humanitarian aid to help meet the needs of those impacted by the Syrian conflict.",
  "id" : 648542721125294080,
  "in_reply_to_status_id" : 648542324167974917,
  "created_at" : "2015-09-28 17:00:08 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648542324167974917",
  "text" : "Nearly 12 million people have been displaced by the conflict in Syria. As Americans, we can't sit idly by. That's not who we are.",
  "id" : 648542324167974917,
  "created_at" : "2015-09-28 16:58:34 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "62MillionGirls",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647912497450606592",
  "text" : "I'm grateful for the teachers who helped spark my sense of curiosity. The #62MillionGirls who aren't in school should have that same chance.",
  "id" : 647912497450606592,
  "created_at" : "2015-09-26 23:15:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646786649251164160",
  "text" : "Yogi Berra was an American original - a Hall of Famer, jovial prophet, &amp; a humble veteran. We'll miss you, Yogi, but your legacy ain't over.",
  "id" : 646786649251164160,
  "created_at" : "2015-09-23 20:42:08 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 28, 37 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646666671864852480",
  "text" : "Welcome to the White House, @Pontifex! Your messages of love, hope, and peace have inspired us all.",
  "id" : 646666671864852480,
  "created_at" : "2015-09-23 12:45:23 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/PJ7xIL6FjY",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GF6yS0aHol",
      "expanded_url" : "https:\/\/twitter.com\/secburwell\/status\/646328750372704256",
      "display_url" : "twitter.com\/secburwell\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646390309551775744",
  "text" : "Millions of families are more secure thanks to the ACA. Join them and #GetCovered on Nov 1: http:\/\/t.co\/PJ7xIL6FjY  https:\/\/t.co\/GF6yS0aHol",
  "id" : 646390309551775744,
  "created_at" : "2015-09-22 18:27:13 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/8kaqY0U3fn",
      "expanded_url" : "http:\/\/vote.usa.gov",
      "display_url" : "vote.usa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "646351288964354049",
  "text" : "Our right to vote is sacred. It's the foundation of our democracy. You can find out how to register to vote at http:\/\/t.co\/8kaqY0U3fn.",
  "id" : 646351288964354049,
  "created_at" : "2015-09-22 15:52:10 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644193755814342656",
  "text" : "Cool clock, Ahmed. Want to bring it to the White House? We should inspire more kids like you to like science. It's what makes America great.",
  "id" : 644193755814342656,
  "created_at" : "2015-09-16 16:58:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643885400847593472",
  "geo" : { },
  "id_str" : "643886166769405952",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We've fought back because of you. We shouldn't slip back because of Congress. I urge them to send me a budget that invests in our future.",
  "id" : 643886166769405952,
  "in_reply_to_status_id" : 643885400847593472,
  "created_at" : "2015-09-15 20:36:39 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/643885400847593472\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/3viaw4b0bB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO-KXBjUsAA90UE.jpg",
      "id_str" : "643885399895486464",
      "id" : 643885399895486464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO-KXBjUsAA90UE.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3viaw4b0bB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643884680253599744",
  "geo" : { },
  "id_str" : "643885400847593472",
  "in_reply_to_user_id" : 1536791610,
  "text" : "When I took office, the budget deficit had reached 9.2% of our GDP. We've cut that down to 2.8%. http:\/\/t.co\/3viaw4b0bB",
  "id" : 643885400847593472,
  "in_reply_to_status_id" : 643884680253599744,
  "created_at" : "2015-09-15 20:33:37 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/643884680253599744\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/3OOqcz8Oxp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO-JtE9UkAADtOj.jpg",
      "id_str" : "643884679255330816",
      "id" : 643884679255330816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO-JtE9UkAADtOj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3OOqcz8Oxp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643883952093073408",
  "geo" : { },
  "id_str" : "643884680253599744",
  "in_reply_to_user_id" : 1536791610,
  "text" : "When I took office, 15.4% of our population was uninsured. Today, we\u2019ve cut that by more than a third. http:\/\/t.co\/3OOqcz8Oxp",
  "id" : 643884680253599744,
  "in_reply_to_status_id" : 643883952093073408,
  "created_at" : "2015-09-15 20:30:45 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643883096689913856",
  "geo" : { },
  "id_str" : "643883952093073408",
  "in_reply_to_user_id" : 1536791610,
  "text" : "In 2009, our auto industry was flatlining. Now our workers are on pace to sell more American cars and trucks than any year since 2001.",
  "id" : 643883952093073408,
  "in_reply_to_status_id" : 643883096689913856,
  "created_at" : "2015-09-15 20:27:51 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/643883096689913856\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/uRfaSoiGuA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO-IQ50VEAEGfkF.jpg",
      "id_str" : "643883095716859905",
      "id" : 643883095716859905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO-IQ50VEAEGfkF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uRfaSoiGuA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643882408283086848",
  "geo" : { },
  "id_str" : "643883096689913856",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We've cut the unemployment rate in half \u2013 from a high of 10% down to 5.1%. And we're not done. http:\/\/t.co\/uRfaSoiGuA",
  "id" : 643883096689913856,
  "in_reply_to_status_id" : 643882408283086848,
  "created_at" : "2015-09-15 20:24:27 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643882148315951104",
  "geo" : { },
  "id_str" : "643882408283086848",
  "in_reply_to_user_id" : 1536791610,
  "text" : "When I took office, 800,000 Americans lost their jobs each month. Our businesses have now added 13.1 million jobs over 66 straight months.",
  "id" : 643882408283086848,
  "in_reply_to_status_id" : 643882148315951104,
  "created_at" : "2015-09-15 20:21:43 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643882148315951104",
  "text" : "7 years ago today, Lehman Brothers filed for bankruptcy, setting off the worst financial crisis in decades. Here's how far we've come:",
  "id" : 643882148315951104,
  "created_at" : "2015-09-15 20:20:41 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 1, 7 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "5TimesFAFSA",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/y1Jv8aeGUH",
      "expanded_url" : "http:\/\/snpy.tv\/1LtQ6v3",
      "display_url" : "snpy.tv\/1LtQ6v3"
    } ]
  },
  "geo" : { },
  "id_str" : "643440607721992192",
  "text" : "\"@FAFSA\" might be hard to say, but filling it out can help you pay for college. FLOTUS, you're up! #5TimesFAFSA http:\/\/t.co\/y1Jv8aeGUH",
  "id" : 643440607721992192,
  "created_at" : "2015-09-14 15:06:10 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642327755221299200",
  "text" : "14 years after the terrorist attacks of 9\/11, we honor those we lost. We salute all who serve to keep us safe. We stand as strong as ever.",
  "id" : 642327755221299200,
  "created_at" : "2015-09-11 13:24:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642084092113256450",
  "text" : "Today's Senate vote on the Iran deal is a historic step toward preventing Iran from obtaining a nuclear weapon. The world is safer for it.",
  "id" : 642084092113256450,
  "created_at" : "2015-09-10 21:15:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bSnaLMs8CU",
      "expanded_url" : "https:\/\/twitter.com\/meetthepress\/status\/640515936647258112",
      "display_url" : "twitter.com\/meetthepress\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640566616925818880",
  "text" : "Thank you, Colin, for putting your experience and expertise behind this important initiative for our country. https:\/\/t.co\/bSnaLMs8CU",
  "id" : 640566616925818880,
  "created_at" : "2015-09-06 16:45:57 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HzWW0S6iQc",
      "expanded_url" : "http:\/\/snpy.tv\/1JQQYbZ",
      "display_url" : "snpy.tv\/1JQQYbZ"
    } ]
  },
  "geo" : { },
  "id_str" : "639508843773468672",
  "text" : "I loved Alaska and met so many inspiring people. Have to keep up the fight on climate change for their sake\u2014and ours. http:\/\/t.co\/HzWW0S6iQc",
  "id" : 639508843773468672,
  "created_at" : "2015-09-03 18:42:44 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]