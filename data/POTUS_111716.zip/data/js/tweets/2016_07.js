Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758867227328163841",
  "text" : "Great speech. She's tested. She's ready. She never quits. That's why Hillary should be our next @POTUS. (She'll get the Twitter handle, too)",
  "id" : 758867227328163841,
  "created_at" : "2016-07-29 03:30:20 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757763701101490176",
  "text" : "Incredible speech by an incredible woman. Couldn't be more proud &amp; our country has been blessed to have her as FLOTUS. I love you, Michelle.",
  "id" : 757763701101490176,
  "created_at" : "2016-07-26 02:25:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/mjlABSm7jF",
      "expanded_url" : "https:\/\/twitter.com\/EPN\/status\/756289302418497536",
      "display_url" : "twitter.com\/EPN\/status\/756\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756568912691601410",
  "text" : "\u00A1Bienvenido, amigo! We value our enduring partnership with Mexico &amp; will work to strengthen it in the years to come. https:\/\/t.co\/mjlABSm7jF",
  "id" : 756568912691601410,
  "created_at" : "2016-07-22 19:17:39 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/755803507760902144\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/c1qFTmq2IV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0nElrUAAAtuKm.jpg",
      "id_str" : "755803272254849024",
      "id" : 755803272254849024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0nElrUAAAtuKm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/c1qFTmq2IV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755803507760902144",
  "text" : "This map says it all. Stay safe as it heats up: Drink water, stay out of the sun, and check on your neighbors. https:\/\/t.co\/c1qFTmq2IV",
  "id" : 755803507760902144,
  "created_at" : "2016-07-20 16:36:13 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/UymO2AaRHg",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2cf646b9-e282-483c-87c3-7cdb02ca6895",
      "display_url" : "amp.twimg.com\/v\/2cf646b9-e28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755043199731675137",
  "text" : "44 men came home because Chuck Kettles believed that we leave no man behind. That's America at our best. https:\/\/t.co\/UymO2AaRHg",
  "id" : 755043199731675137,
  "created_at" : "2016-07-18 14:15:01 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/5T8rvSRp9e",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/146bf05b-4ac0-49e4-8eab-322885e67fe5",
      "display_url" : "amp.twimg.com\/v\/146bf05b-4ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753403382744780800",
  "text" : "Congrats Carla Hayden, our newest Librarian of Congress! Her confirmation is certainly one for the history books.\nhttps:\/\/t.co\/5T8rvSRp9e",
  "id" : 753403382744780800,
  "created_at" : "2016-07-14 01:38:58 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA's Juno Mission",
      "screen_name" : "NASAJuno",
      "indices" : [ 124, 133 ],
      "id_str" : "19789439",
      "id" : 19789439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750379001546416128",
  "text" : "Incredible! After a 5-year journey, we're up close and personal with our solar system's largest planet. Welcome to Jupiter, @NASAJuno!",
  "id" : 750379001546416128,
  "created_at" : "2016-07-05 17:21:09 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749966042135293952",
  "text" : "Happy Fourth of July, everybody! And to our brave men and women in uniform: On this day and every day, we thank you.",
  "id" : 749966042135293952,
  "created_at" : "2016-07-04 14:00:12 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749378629822545920",
  "text" : "Elie Wiesel was a great moral voice of our time and a conscience for our world. He was also a dear friend. We will miss him deeply.",
  "id" : 749378629822545920,
  "created_at" : "2016-07-02 23:06:02 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]