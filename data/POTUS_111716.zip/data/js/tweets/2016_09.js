Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781639251528081409",
  "text" : "Our Olympians and Paralympians show the world that no matter what, with perseverance, we can do incredible things. Proud of you, #TeamUSA.",
  "id" : 781639251528081409,
  "created_at" : "2016-09-29 23:38:14 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 26, 41 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780906000391864320",
  "text" : "Couldn't be more proud of @HillaryClinton. Her vision and command during last night's debate showed that she's ready to be our next @POTUS.",
  "id" : 780906000391864320,
  "created_at" : "2016-09-27 23:04:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/sUxB8TLc5r",
      "expanded_url" : "http:\/\/www.vote.gov",
      "display_url" : "vote.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "780809121314504704",
  "text" : "Democracy is not a spectator sport. Don't give up your power to shape the future of the country we love. Vote: https:\/\/t.co\/sUxB8TLc5r",
  "id" : 780809121314504704,
  "created_at" : "2016-09-27 16:39:35 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT National News",
      "screen_name" : "NYTNational",
      "indices" : [ 3, 15 ],
      "id_str" : "1767741",
      "id" : 1767741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780480428872306688",
  "text" : "RT @NYTNational: Census data shows 3.5 million Americans were able to raise their chins above the poverty line last year https:\/\/t.co\/FEr5e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/FEr5eyGUrz",
        "expanded_url" : "http:\/\/nyti.ms\/2dbl0Pf",
        "display_url" : "nyti.ms\/2dbl0Pf"
      } ]
    },
    "geo" : { },
    "id_str" : "780219092573753344",
    "text" : "Census data shows 3.5 million Americans were able to raise their chins above the poverty line last year https:\/\/t.co\/FEr5eyGUrz",
    "id" : 780219092573753344,
    "created_at" : "2016-09-26 01:35:02 +0000",
    "user" : {
      "name" : "NYT National News",
      "screen_name" : "NYTNational",
      "protected" : false,
      "id_str" : "1767741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2045298093\/NYT_Twitter_national_normal.png",
      "id" : 1767741,
      "verified" : true
    }
  },
  "id" : 780480428872306688,
  "created_at" : "2016-09-26 18:53:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/780244157625278464\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/UlyfpIBOL2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtP41_-UAAAmQ9d.jpg",
      "id_str" : "780240767054774272",
      "id" : 780240767054774272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtP41_-UAAAmQ9d.jpg",
      "sizes" : [ {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/UlyfpIBOL2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780244157625278464",
  "text" : "Here's to The King who was as extraordinary on the links as he was generous to others. Thanks for the memories, Arnold. https:\/\/t.co\/UlyfpIBOL2",
  "id" : 780244157625278464,
  "created_at" : "2016-09-26 03:14:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian NMAAHC",
      "screen_name" : "NMAAHC",
      "indices" : [ 19, 26 ],
      "id_str" : "36972997",
      "id" : 36972997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779683020043419649",
  "text" : "Proud to help open @NMAAHC with so many heroes. African American history is a central part of our glorious American history.",
  "id" : 779683020043419649,
  "created_at" : "2016-09-24 14:04:52 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772970240602836992",
  "text" : "Sabaidii, Laos! Honored to be the first U.S. president to visit Laos and to begin a new partnership between our countries.",
  "id" : 772970240602836992,
  "created_at" : "2016-09-06 01:30:41 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772841067276333056",
  "text" : "Happy Labor Day - longest streak of job growth ever, unemployment cut in half. That's what hardworking Americans can do. Let's keep going!",
  "id" : 772841067276333056,
  "created_at" : "2016-09-05 16:57:23 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]