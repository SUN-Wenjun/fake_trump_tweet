Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ZGeTDm6OYw",
      "expanded_url" : "http:\/\/wapo.st\/1iia2cP",
      "display_url" : "wapo.st\/1iia2cP"
    } ]
  },
  "geo" : { },
  "id_str" : "659775465352249344",
  "text" : "Who knew community policing could involve the Nae Nae? Great example of police having fun while keeping us safe: https:\/\/t.co\/ZGeTDm6OYw",
  "id" : 659775465352249344,
  "created_at" : "2015-10-29 16:55:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 52, 65 ],
      "id_str" : "16212685",
      "id" : 16212685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeeRed",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659196797701763072",
  "text" : "Good to be home for a night. Even better to see the @chicagobulls start the season off right! #SeeRed",
  "id" : 659196797701763072,
  "created_at" : "2015-10-28 02:35:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657641041361817600",
  "text" : "Our thoughts are with the Mexican people as they brace for Hurricane Patricia. USAID disaster experts are on the ground and ready to help.",
  "id" : 657641041361817600,
  "created_at" : "2015-10-23 19:33:37 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael J. Fox",
      "screen_name" : "realmikefox",
      "indices" : [ 30, 42 ],
      "id_str" : "398092540",
      "id" : 398092540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656926385882185728",
  "text" : "Happy Back to the Future Day, @RealMikeFox! Ever think about the fact that we live in the future we dreamed of then? That's heavy, man.",
  "id" : 656926385882185728,
  "created_at" : "2015-10-21 20:13:50 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656893143015526404",
  "geo" : { },
  "id_str" : "656894040319791104",
  "in_reply_to_user_id" : 1536791610,
  "text" : "So I'm eager to hear from folks in Charleston today on actions we can take to put recovery within reach for anyone who needs it.",
  "id" : 656894040319791104,
  "in_reply_to_status_id" : 656893143015526404,
  "created_at" : "2015-10-21 18:05:18 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656892337939845120",
  "geo" : { },
  "id_str" : "656893143015526404",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Communities are showing that we should approach substance use disorders as an opportunity to intervene rather than a race to incarcerate.",
  "id" : 656893143015526404,
  "in_reply_to_status_id" : 656892337939845120,
  "created_at" : "2015-10-21 18:01:44 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656891501520130048",
  "geo" : { },
  "id_str" : "656892337939845120",
  "in_reply_to_user_id" : 1536791610,
  "text" : "With no other disease do we expect people to wait until they're a danger to themselves or others to self-diagnose and seek treatment.",
  "id" : 656892337939845120,
  "in_reply_to_status_id" : 656891501520130048,
  "created_at" : "2015-10-21 17:58:32 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656890709555843072",
  "geo" : { },
  "id_str" : "656891501520130048",
  "in_reply_to_user_id" : 1536791610,
  "text" : "4 in 5 heroin users started out by misusing prescription opioids. Heroin-related deaths nearly quadrupled between 2002 and 2013.",
  "id" : 656891501520130048,
  "in_reply_to_status_id" : 656890709555843072,
  "created_at" : "2015-10-21 17:55:13 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656889814201991168",
  "geo" : { },
  "id_str" : "656890709555843072",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Sales of powerful painkillers have skyrocketed. In 2012, enough prescriptions were written to give every American adult a bottle of pills.",
  "id" : 656890709555843072,
  "in_reply_to_status_id" : 656889814201991168,
  "created_at" : "2015-10-21 17:52:04 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656889342200188928",
  "geo" : { },
  "id_str" : "656889814201991168",
  "in_reply_to_user_id" : 1536791610,
  "text" : "120 Americans die every day from drug overdoses - most involving legal prescription drugs. That's more than from car crashes.",
  "id" : 656889814201991168,
  "in_reply_to_status_id" : 656889342200188928,
  "created_at" : "2015-10-21 17:48:30 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656889342200188928",
  "text" : "Heading to West Virginia today to talk about the epidemic of prescription drug abuse in America and what we can do to help. The facts:",
  "id" : 656889342200188928,
  "created_at" : "2015-10-21 17:46:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656546367083532292",
  "text" : "RT @FactsOnClimate: Climate change threatens us all, and it will take all of us to solve it. Get the facts on how we can: https:\/\/t.co\/D0uI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/D0uInQ4O6t",
        "expanded_url" : "http:\/\/go.wh.gov\/Climate",
        "display_url" : "go.wh.gov\/Climate"
      } ]
    },
    "geo" : { },
    "id_str" : "656496631362297857",
    "text" : "Climate change threatens us all, and it will take all of us to solve it. Get the facts on how we can: https:\/\/t.co\/D0uInQ4O6t #ActOnClimate",
    "id" : 656496631362297857,
    "created_at" : "2015-10-20 15:46:08 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 656546367083532292,
  "created_at" : "2015-10-20 19:03:46 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 36, 50 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JVLzYDQ8Jo",
      "expanded_url" : "http:\/\/snpy.tv\/1LkWhV5",
      "display_url" : "snpy.tv\/1LkWhV5"
    } ]
  },
  "geo" : { },
  "id_str" : "656263630741073920",
  "text" : "I got a chance to catch up with the @Space_Station crew today. Nothing like a call to space on #AstronomyNight! https:\/\/t.co\/JVLzYDQ8Jo",
  "id" : 656263630741073920,
  "created_at" : "2015-10-20 00:20:17 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656153597932118018",
  "text" : "I just met with CEOs of some of our biggest companies who are stepping up to #ActOnClimate. It's good for the planet - and the bottom line.",
  "id" : 656153597932118018,
  "created_at" : "2015-10-19 17:03:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H\u014Dk\u016Ble\u2018a",
      "screen_name" : "HokuleaWWV",
      "indices" : [ 9, 20 ],
      "id_str" : "21330459",
      "id" : 21330459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MalamaHonua",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655044746759438336",
  "text" : "Congrats @HokuleaWWV on reaching Africa\u2014midpoint of worldwide voyage to spread message of caring for the one planet we've got. #MalamaHonua",
  "id" : 655044746759438336,
  "created_at" : "2015-10-16 15:36:52 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 9, 14 ],
      "id_str" : "41144996",
      "id" : 41144996
    }, {
      "name" : "Chicago White Sox",
      "screen_name" : "whitesox",
      "indices" : [ 22, 31 ],
      "id_str" : "53197137",
      "id" : 53197137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654094154176315392",
  "text" : "Congrats @Cubs - even @whitesox fans are rooting for you!",
  "id" : 654094154176315392,
  "created_at" : "2015-10-14 00:39:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/gOGzWmYdxQ",
      "expanded_url" : "https:\/\/twitter.com\/zackbeauchamp\/status\/649727266835046400",
      "display_url" : "twitter.com\/zackbeauchamp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649748792099622912",
  "text" : "Thanks, Zack. https:\/\/t.co\/gOGzWmYdxQ",
  "id" : 649748792099622912,
  "created_at" : "2015-10-02 00:52:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]