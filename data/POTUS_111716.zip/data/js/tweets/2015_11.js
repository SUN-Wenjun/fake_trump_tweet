Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/qQ6wCZUR1Z",
      "expanded_url" : "https:\/\/twitter.com\/billgates\/status\/671325937749872640",
      "display_url" : "twitter.com\/billgates\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671365993399255040",
  "text" : "Addressing climate change takes all of us, especially the private sector going all-in on clean energy worldwide. https:\/\/t.co\/qQ6wCZUR1Z",
  "id" : 671365993399255040,
  "created_at" : "2015-11-30 16:31:40 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/671094262826704896\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/nrNiwDAKuN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVA0q8DWEAArvm0.jpg",
      "id_str" : "671094256757510144",
      "id" : 671094256757510144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVA0q8DWEAArvm0.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nrNiwDAKuN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671094262826704896",
  "text" : "Good news: the world now adds more clean power capacity each year than dirtier fossil-fuel based power capacity. https:\/\/t.co\/nrNiwDAKuN",
  "id" : 671094262826704896,
  "created_at" : "2015-11-29 22:31:55 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/670745089975721984\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/udTcIhxtOC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7292FWsAAYkhx.jpg",
      "id_str" : "670744936875208704",
      "id" : 670744936875208704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7292FWsAAYkhx.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/udTcIhxtOC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670745089975721984",
  "text" : "Enjoyed stopping by Upshur Street Books today. Celebrate Small Business Saturday by supporting a business near you. https:\/\/t.co\/udTcIhxtOC",
  "id" : 670745089975721984,
  "created_at" : "2015-11-28 23:24:25 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669923936574922752",
  "text" : "Happy Thanksgiving, everyone! Today, we give thanks for all of our loved ones and the brave men and women in uniform who serve our country.",
  "id" : 669923936574922752,
  "created_at" : "2015-11-26 17:01:27 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667021076094976002",
  "geo" : { },
  "id_str" : "667021784726769665",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Slamming the door in the face of refugees would betray our deepest values. That's not who we are. And it's not what we're going to do.",
  "id" : 667021784726769665,
  "in_reply_to_status_id" : 667021076094976002,
  "created_at" : "2015-11-18 16:49:20 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667020445066096640",
  "geo" : { },
  "id_str" : "667021076094976002",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Welcoming the world\u2019s vulnerable who seek the safety of America is not new to us. We've safely welcomed 3 million refugees since 1975.",
  "id" : 667021076094976002,
  "in_reply_to_status_id" : 667020445066096640,
  "created_at" : "2015-11-18 16:46:31 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667019888234528768",
  "geo" : { },
  "id_str" : "667020445066096640",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Here, our focus is giving safe haven to the most vulnerable Syrians \u2013 women, children, and survivors of torture.",
  "id" : 667020445066096640,
  "in_reply_to_status_id" : 667019888234528768,
  "created_at" : "2015-11-18 16:44:01 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667019384225996800",
  "geo" : { },
  "id_str" : "667019888234528768",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We will provide refuge to at least 10,000 refugees fleeing violence in Syria over the next year after they pass the highest security checks.",
  "id" : 667019888234528768,
  "in_reply_to_status_id" : 667019384225996800,
  "created_at" : "2015-11-18 16:41:48 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667018696137773056",
  "geo" : { },
  "id_str" : "667019384225996800",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We also win this fight with our values. America can ensure our own security while welcoming refugees desperately seeking safety from ISIL.",
  "id" : 667019384225996800,
  "in_reply_to_status_id" : 667018696137773056,
  "created_at" : "2015-11-18 16:39:48 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667018696137773056",
  "text" : "Protecting the American people is my top priority. With our 65 global partners, we're leading the campaign to degrade and destroy ISIL.",
  "id" : 667018696137773056,
  "created_at" : "2015-11-18 16:37:04 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/664853410135613440\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WdWAPswJpE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CToIlGpVEAAYn35.jpg",
      "id_str" : "664853328522711040",
      "id" : 664853328522711040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CToIlGpVEAAYn35.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/WdWAPswJpE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664853410135613440",
  "text" : "This is an American hero: Capt. Groberg put it all on the line for his team. On his worst day, he gave us his best. https:\/\/t.co\/WdWAPswJpE",
  "id" : 664853410135613440,
  "created_at" : "2015-11-12 17:13:00 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664466446102216704",
  "text" : "Today, we honor the incredible men and women who have served our country. Their sacrifice and selflessness is second to none.",
  "id" : 664466446102216704,
  "created_at" : "2015-11-11 15:35:20 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WG5y1FbhIA",
      "expanded_url" : "http:\/\/Facebook.com\/POTUS",
      "display_url" : "Facebook.com\/POTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "663813521289953281",
  "text" : "I just launched my Facebook page with a video on climate change. America will lead on this. The time to act is now. https:\/\/t.co\/WG5y1FbhIA",
  "id" : 663813521289953281,
  "created_at" : "2015-11-09 20:20:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/PJ7xIL6FjY",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "660866496474832896",
  "text" : "Every American deserves quality, affordable health care. If you or a friend needs coverage, go to https:\/\/t.co\/PJ7xIL6FjY and sign up now.",
  "id" : 660866496474832896,
  "created_at" : "2015-11-01 17:10:25 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]