Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627211041466941441",
  "text" : "Launching a pilot program to help students in prison pay for college, because everyone willing to work for it deserves a second chance.",
  "id" : 627211041466941441,
  "created_at" : "2015-07-31 20:15:39 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626794365869010945",
  "text" : "Happy 50th birthday, Medicare and Medicaid! Two programs, one promise: that every American deserves a basic measure of dignity and security.",
  "id" : 626794365869010945,
  "created_at" : "2015-07-30 16:39:56 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625411767414444032",
  "text" : "25 years of the ADA and Americans with disabilities are breaking more barriers than ever, making all of us more free. Let's keep going.",
  "id" : 625411767414444032,
  "created_at" : "2015-07-26 21:05:59 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624691954224365568",
  "text" : "Proud to be the first American President to visit Kenya. Happy to see family, and to talk with young Kenyans about the future.",
  "id" : 624691954224365568,
  "created_at" : "2015-07-24 21:25:42 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623661992952377344",
  "text" : "E.L. Doctorow was one of America's greatest novelists. His books taught me much, and he will be missed.",
  "id" : 623661992952377344,
  "created_at" : "2015-07-22 01:13:00 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623502798366351360",
  "text" : "RT @TheIranDeal: The historic #IranDeal succeeds in verifying that Iran cannot obtain a nuclear weapon. Follow to get the facts: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Ua7p0Qzryo",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDealFacts",
        "display_url" : "go.wh.gov\/IranDealFacts"
      } ]
    },
    "geo" : { },
    "id_str" : "623500231666221056",
    "text" : "The historic #IranDeal succeeds in verifying that Iran cannot obtain a nuclear weapon. Follow to get the facts: http:\/\/t.co\/Ua7p0Qzryo",
    "id" : 623500231666221056,
    "created_at" : "2015-07-21 14:30:13 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 623502798366351360,
  "created_at" : "2015-07-21 14:40:25 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 41, 46 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/623137065341952000\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JQ3174P0LF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKXT2ptWIAAQ6lk.jpg",
      "id_str" : "623137059323125760",
      "id" : 623137059323125760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKXT2ptWIAAQ6lk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JQ3174P0LF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623137065341952000",
  "text" : "Just got this new blue marble photo from @NASA. A beautiful reminder that we need to protect the only planet we have. http:\/\/t.co\/JQ3174P0LF",
  "id" : 623137065341952000,
  "created_at" : "2015-07-20 14:27:08 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/622147491862028289\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EeeIC3AK4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKJPxjcUEAAy7Kl.jpg",
      "id_str" : "622147411276730368",
      "id" : 622147411276730368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKJPxjcUEAAy7Kl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EeeIC3AK4A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622147491862028289",
  "text" : "Had a great visit today with Emma Didlake - our oldest living veteran at 110-years-young! She's a true American hero. http:\/\/t.co\/EeeIC3AK4A",
  "id" : 622147491862028289,
  "created_at" : "2015-07-17 20:54:55 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622091025541136384",
  "text" : "Congrats to Oregon on passing two years of free community college! Every hardworking student deserves access to higher education.",
  "id" : 622091025541136384,
  "created_at" : "2015-07-17 17:10:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 41, 46 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/621133763385425920\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/FfztBSMbK0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ611aJUkAAGaqP.jpg",
      "id_str" : "621133727779819520",
      "id" : 621133727779819520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ611aJUkAAGaqP.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FfztBSMbK0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621133763385425920",
  "text" : "Pluto just had its first visitor! Thanks @NASA - it's a great day for discovery and American leadership. http:\/\/t.co\/FfztBSMbK0",
  "id" : 621133763385425920,
  "created_at" : "2015-07-15 01:46:43 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/xwSrH9IoFG",
      "expanded_url" : "https:\/\/twitter.com\/tomfriedman\/status\/621084602644471810",
      "display_url" : "twitter.com\/tomfriedman\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621121462649397249",
  "text" : "Good conversation with Tom Friedman on the deal we reached with Iran. It's a major step toward a safer world.  https:\/\/t.co\/xwSrH9IoFG",
  "id" : 621121462649397249,
  "created_at" : "2015-07-15 00:57:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621087343253057541",
  "geo" : { },
  "id_str" : "621088588583800832",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Mass incarceration doesn't work. Let's build communities that give kids a shot at success and prisons that prepare people for a 2nd chance.",
  "id" : 621088588583800832,
  "in_reply_to_status_id" : 621087343253057541,
  "created_at" : "2015-07-14 22:47:13 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621086198254145536",
  "geo" : { },
  "id_str" : "621087343253057541",
  "in_reply_to_user_id" : 1536791610,
  "text" : "We could eliminate tuition at every public college and university in America with the $80 billion we spend each year on incarcerations.",
  "id" : 621087343253057541,
  "in_reply_to_status_id" : 621086198254145536,
  "created_at" : "2015-07-14 22:42:16 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621085397007888384",
  "geo" : { },
  "id_str" : "621086198254145536",
  "in_reply_to_user_id" : 1536791610,
  "text" : "The $80 billion we spend each year on incarcerations could double the salary of every high school teacher in America.",
  "id" : 621086198254145536,
  "in_reply_to_status_id" : 621085397007888384,
  "created_at" : "2015-07-14 22:37:43 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621084469970214914",
  "geo" : { },
  "id_str" : "621085397007888384",
  "in_reply_to_user_id" : 1536791610,
  "text" : "The $80 billion we spend each year to keep people incarcerated could pay for universal pre-K for every 3-year-old and 4-year-old in America.",
  "id" : 621085397007888384,
  "in_reply_to_status_id" : 621084469970214914,
  "created_at" : "2015-07-14 22:34:32 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621083313063763968",
  "geo" : { },
  "id_str" : "621084469970214914",
  "in_reply_to_user_id" : 1536791610,
  "text" : "In 1980, there were 500,000 people in American jails. Today, there are 2.2 million. Many belong. But too many are nonviolent offenders.",
  "id" : 621084469970214914,
  "in_reply_to_status_id" : 621083313063763968,
  "created_at" : "2015-07-14 22:30:51 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621081946236563456",
  "geo" : { },
  "id_str" : "621083313063763968",
  "in_reply_to_user_id" : 1536791610,
  "text" : "America keeps more people behind bars than the top 35 European countries combined.",
  "id" : 621083313063763968,
  "in_reply_to_status_id" : 621081946236563456,
  "created_at" : "2015-07-14 22:26:15 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621081548029345792",
  "geo" : { },
  "id_str" : "621081946236563456",
  "in_reply_to_user_id" : 1536791610,
  "text" : "America is home to 5% of the world's population, but 25% of the world's prisoners.",
  "id" : 621081946236563456,
  "in_reply_to_status_id" : 621081548029345792,
  "created_at" : "2015-07-14 22:20:49 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621081548029345792",
  "text" : "Just spoke to the NAACP about criminal justice reform, something many broadly agree on. Some stats:",
  "id" : 621081548029345792,
  "created_at" : "2015-07-14 22:19:14 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619509587272691712",
  "text" : "South Carolina taking down the confederate flag - a signal of good will and healing, and a meaningful step towards a better future.",
  "id" : 619509587272691712,
  "created_at" : "2015-07-10 14:12:50 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carli Lloyd",
      "screen_name" : "CarliLloyd",
      "indices" : [ 36, 47 ],
      "id_str" : "110195330",
      "id" : 110195330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617860799953010688",
  "text" : "What a win for Team USA! Great game @CarliLloyd! Your country is so proud of all of you. Come visit the White House with the World Cup soon.",
  "id" : 617860799953010688,
  "created_at" : "2015-07-06 01:01:08 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/617542692952764417\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Ft3DwYWRJv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJHzzhOWIAAWQNk.jpg",
      "id_str" : "617542690343886848",
      "id" : 617542690343886848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJHzzhOWIAAWQNk.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Ft3DwYWRJv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617430014422843392",
  "geo" : { },
  "id_str" : "617542692952764417",
  "in_reply_to_user_id" : 1536791610,
  "text" : "http:\/\/t.co\/Ft3DwYWRJv",
  "id" : 617542692952764417,
  "in_reply_to_status_id" : 617430014422843392,
  "created_at" : "2015-07-05 03:57:06 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617430014422843392",
  "text" : "It doesn't get much better than celebrating America with the people you love. Happy Fourth of July, everyone!",
  "id" : 617430014422843392,
  "created_at" : "2015-07-04 20:29:21 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/srZKB6plzz",
      "expanded_url" : "https:\/\/twitter.com\/theblackkeys\/status\/616364682895564800",
      "display_url" : "twitter.com\/theblackkeys\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616441802023960576",
  "text" : "It's not mine; just a loaner. Maybe you can come play at the White House sometime instead?  https:\/\/t.co\/srZKB6plzz",
  "id" : 616441802023960576,
  "created_at" : "2015-07-02 03:02:33 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie C. Keys",
      "screen_name" : "hotelkeys",
      "indices" : [ 3, 13 ],
      "id_str" : "100005598",
      "id" : 100005598
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616418071683665920",
  "text" : "RT @hotelkeys: @POTUS \n23yrold recent grad has full-time job but no insurance. Peace of mind that she can be on our plan. #ACAWorks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "616340901351264256",
    "geo" : { },
    "id_str" : "616341623128084480",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS \n23yrold recent grad has full-time job but no insurance. Peace of mind that she can be on our plan. #ACAWorks",
    "id" : 616341623128084480,
    "in_reply_to_status_id" : 616340901351264256,
    "created_at" : "2015-07-01 20:24:28 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Connie C. Keys",
      "screen_name" : "hotelkeys",
      "protected" : false,
      "id_str" : "100005598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735454188621139969\/y6wP4Sce_normal.jpg",
      "id" : 100005598,
      "verified" : false
    }
  },
  "id" : 616418071683665920,
  "created_at" : "2015-07-02 01:28:15 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katriena Knights",
      "screen_name" : "crazywritinfool",
      "indices" : [ 3, 19 ],
      "id_str" : "7713582",
      "id" : 7713582
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616417443246907392",
  "text" : "RT @crazywritinfool: @POTUS #ACAWorks because I could switch insurance providers to get a lower rate. Couldn't before due to \"preexisting c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 7, 16 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "616340901351264256",
    "geo" : { },
    "id_str" : "616376283870527488",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS #ACAWorks because I could switch insurance providers to get a lower rate. Couldn't before due to \"preexisting conditions\"",
    "id" : 616376283870527488,
    "in_reply_to_status_id" : 616340901351264256,
    "created_at" : "2015-07-01 22:42:12 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Katriena Knights",
      "screen_name" : "crazywritinfool",
      "protected" : false,
      "id_str" : "7713582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745011872823316480\/3yb-Q0Cu_normal.jpg",
      "id" : 7713582,
      "verified" : false
    }
  },
  "id" : 616417443246907392,
  "created_at" : "2015-07-02 01:25:45 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley",
      "screen_name" : "RandynAverysMom",
      "indices" : [ 3, 19 ],
      "id_str" : "17515958",
      "id" : 17515958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "ACA",
      "indices" : [ 84, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616416832157818880",
  "text" : "RT @RandynAverysMom: #AskPOTUS my dad is a small biz owner and never had insurance. #ACA allowed him access to life saving cancer screening\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ACA",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "ACAWorks",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616315904578723840",
    "text" : "#AskPOTUS my dad is a small biz owner and never had insurance. #ACA allowed him access to life saving cancer screening this year. #ACAWorks",
    "id" : 616315904578723840,
    "created_at" : "2015-07-01 18:42:16 +0000",
    "user" : {
      "name" : "Ashley",
      "screen_name" : "RandynAverysMom",
      "protected" : false,
      "id_str" : "17515958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499735092177010690\/7qcZLZBi_normal.jpeg",
      "id" : 17515958,
      "verified" : false
    }
  },
  "id" : 616416832157818880,
  "created_at" : "2015-07-02 01:23:19 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The_Notorious_PhD",
      "screen_name" : "NotoriousLLT",
      "indices" : [ 3, 16 ],
      "id_str" : "1016746238",
      "id" : 1016746238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616416358096572416",
  "text" : "RT @NotoriousLLT: Sister is legally blind &amp; on disability b\/c of glaucoma. She needs care to keep sight she has left. With #ACA she can aff\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 109, 113 ]
      }, {
        "text" : "ACAWorks",
        "indices" : [ 133, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616343773090549765",
    "text" : "Sister is legally blind &amp; on disability b\/c of glaucoma. She needs care to keep sight she has left. With #ACA she can afford it! #ACAWorks",
    "id" : 616343773090549765,
    "created_at" : "2015-07-01 20:33:01 +0000",
    "user" : {
      "name" : "The_Notorious_PhD",
      "screen_name" : "NotoriousLLT",
      "protected" : false,
      "id_str" : "1016746238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680224064867299328\/v9rv29K4_normal.jpg",
      "id" : 1016746238,
      "verified" : false
    }
  },
  "id" : 616416358096572416,
  "created_at" : "2015-07-02 01:21:26 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616340901351264256",
  "text" : "Gotta go, but this was fun. Let's keep the health care conversation going - share how the #ACAWorks for you or your family.",
  "id" : 616340901351264256,
  "created_at" : "2015-07-01 20:21:36 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/IqbyUmcbmJ",
      "expanded_url" : "https:\/\/twitter.com\/Matt_Rodewald\/status\/616313502932844544",
      "display_url" : "twitter.com\/Matt_Rodewald\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616339969125302276",
  "text" : "butler's a great player on o and d; let's sign him up long term. go bulls! https:\/\/t.co\/IqbyUmcbmJ",
  "id" : 616339969125302276,
  "created_at" : "2015-07-01 20:17:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/vFCDgMXSE9",
      "expanded_url" : "https:\/\/twitter.com\/jayrocky_vs\/status\/616312088282140673",
      "display_url" : "twitter.com\/jayrocky_vs\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616339733132804096",
  "text" : "people lack info\/turned off by political noise. w court case done, let's focus on getting people signed up. https:\/\/t.co\/vFCDgMXSE9",
  "id" : 616339733132804096,
  "created_at" : "2015-07-01 20:16:58 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/dTbTNDQSII",
      "expanded_url" : "https:\/\/twitter.com\/ryann1232\/status\/616329450129608704",
      "display_url" : "twitter.com\/ryann1232\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616338933962670080",
  "text" : "pushing to make 2 yrs comm college free; permit refinancing on student loans; push colleges to keep tuition low https:\/\/t.co\/dTbTNDQSII",
  "id" : 616338933962670080,
  "created_at" : "2015-07-01 20:13:47 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/MEEI8QHH1V",
      "expanded_url" : "https:\/\/twitter.com\/JGreenDC\/status\/616311940957253632",
      "display_url" : "twitter.com\/JGreenDC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616338528138608640",
  "text" : "respect the nyt, but not buying peas in guac. onions, garlic, hot peppers. classic. https:\/\/t.co\/MEEI8QHH1V",
  "id" : 616338528138608640,
  "created_at" : "2015-07-01 20:12:10 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1DP6CRdwlm",
      "expanded_url" : "https:\/\/twitter.com\/theonIyreasn\/status\/616329416155607040",
      "display_url" : "twitter.com\/theonIyreasn\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616338019843461121",
  "text" : "was listening to outkast\/liberation and the black keys\/lonely boy this morning. https:\/\/t.co\/1DP6CRdwlm",
  "id" : 616338019843461121,
  "created_at" : "2015-07-01 20:10:09 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/XWFEKbZCaT",
      "expanded_url" : "https:\/\/twitter.com\/christinaloucks\/status\/616314593363648516",
      "display_url" : "twitter.com\/christinalouck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616337692582899712",
  "text" : "there's a hardship exemption; fine only applies to folks who can afford insurance but choose not to. https:\/\/t.co\/XWFEKbZCaT",
  "id" : 616337692582899712,
  "created_at" : "2015-07-01 20:08:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QqbgflhXDY",
      "expanded_url" : "https:\/\/twitter.com\/fieldemma47\/status\/616335592914206721",
      "display_url" : "twitter.com\/fieldemma47\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616337090767405056",
  "text" : "have principles and issues you are passionate about, and act; worry more about doing something than being something. https:\/\/t.co\/QqbgflhXDY",
  "id" : 616337090767405056,
  "created_at" : "2015-07-01 20:06:28 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UeBhgiL64B",
      "expanded_url" : "https:\/\/twitter.com\/SableSys\/status\/616324400091037696",
      "display_url" : "twitter.com\/SableSys\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616336742854078464",
  "text" : "EX-IM bank helps US companies export; that means good paying american jobs. optimistic that congress gets it done. https:\/\/t.co\/UeBhgiL64B",
  "id" : 616336742854078464,
  "created_at" : "2015-07-01 20:05:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QqUY3S9MoC",
      "expanded_url" : "https:\/\/twitter.com\/katrobison\/status\/616328255344394241",
      "display_url" : "twitter.com\/katrobison\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616336192443916289",
  "text" : "now's time to encourage states that held off for political reasons to do the right thing; contact state officials! https:\/\/t.co\/QqUY3S9MoC",
  "id" : 616336192443916289,
  "created_at" : "2015-07-01 20:02:53 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/ymGM0HARad",
      "expanded_url" : "https:\/\/twitter.com\/nathan210\/status\/616324467296477184",
      "display_url" : "twitter.com\/nathan210\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616335694928199680",
  "text" : "congratulations! hope you guys are getting sleep. nothing beats babies! https:\/\/t.co\/ymGM0HARad",
  "id" : 616335694928199680,
  "created_at" : "2015-07-01 20:00:55 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/WfJI2AOLkP",
      "expanded_url" : "https:\/\/twitter.com\/RaulieGonzo\/status\/616323201480720384",
      "display_url" : "twitter.com\/RaulieGonzo\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616335347174232064",
  "text" : "not true - like last year, insurers request premium hikes, but must be approved; expect final increases to be less   https:\/\/t.co\/WfJI2AOLkP",
  "id" : 616335347174232064,
  "created_at" : "2015-07-01 19:59:32 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/S9RlkVB1An",
      "expanded_url" : "https:\/\/twitter.com\/TheRealDylanG\/status\/616313067362586624",
      "display_url" : "twitter.com\/TheRealDylanG\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616334401157378048",
  "text" : "we need to encourage states to take advantage of medicaid expansion; could insure 4 mil more people in 22 states! https:\/\/t.co\/S9RlkVB1An",
  "id" : 616334401157378048,
  "created_at" : "2015-07-01 19:55:46 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/616334258697859073\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wK8RDF2H0i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CI2oukAUsAA0GJG.jpg",
      "id_str" : "616334241912107008",
      "id" : 616334241912107008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI2oukAUsAA0GJG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wK8RDF2H0i"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616334258697859073",
  "text" : "Alright, let's do this. Ready to answer your health care questions. Keep 'em coming with #AskPOTUS. http:\/\/t.co\/wK8RDF2H0i",
  "id" : 616334258697859073,
  "created_at" : "2015-07-01 19:55:12 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616311028847112192",
  "text" : "Hello from Nashville! I'll be answering your questions on health care and the Affordable Care Act at 3:30pm ET. Tweet yours using #AskPOTUS.",
  "id" : 616311028847112192,
  "created_at" : "2015-07-01 18:22:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]