Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "March of Dimes",
      "screen_name" : "MarchofDimes",
      "indices" : [ 3, 16 ],
      "id_str" : "8539242",
      "id" : 8539242
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZAPzika",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748666260599218177",
  "text" : "RT @MarchofDimes: 2016 Nat'l Amb. Ismael was honored to meet @POTUS today &amp; talk about the need to help babies &amp; #ZAPzika! https:\/\/t.co\/Zzw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 43, 49 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarchofDimes\/status\/748657015141072896\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZzwGUUV6Gu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmPDlElWAAAibUU.jpg",
        "id_str" : "748657004726583296",
        "id" : 748657004726583296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmPDlElWAAAibUU.jpg",
        "sizes" : [ {
          "h" : 1366,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ZzwGUUV6Gu"
      } ],
      "hashtags" : [ {
        "text" : "ZAPzika",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748657015141072896",
    "text" : "2016 Nat'l Amb. Ismael was honored to meet @POTUS today &amp; talk about the need to help babies &amp; #ZAPzika! https:\/\/t.co\/ZzwGUUV6Gu",
    "id" : 748657015141072896,
    "created_at" : "2016-06-30 23:18:36 +0000",
    "user" : {
      "name" : "March of Dimes",
      "screen_name" : "MarchofDimes",
      "protected" : false,
      "id_str" : "8539242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779338801596555264\/3E-GNBJ8_normal.jpg",
      "id" : 8539242,
      "verified" : true
    }
  },
  "id" : 748666260599218177,
  "created_at" : "2016-06-30 23:55:20 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/748621673578958849\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/l8nChcXpml",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOjOUPWEAQIbZG.jpg",
      "id_str" : "748621429420199940",
      "id" : 748621429420199940,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOjOUPWEAQIbZG.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l8nChcXpml"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748621170015076352",
  "geo" : { },
  "id_str" : "748621673578958849",
  "in_reply_to_user_id" : 1536791610,
  "text" : "The list goes on. When Members return, I hope they'll share my commitment to work together to do what must be done. https:\/\/t.co\/l8nChcXpml",
  "id" : 748621673578958849,
  "in_reply_to_status_id" : 748621170015076352,
  "created_at" : "2016-06-30 20:58:10 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748620897309757440",
  "geo" : { },
  "id_str" : "748621170015076352",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Americans still need and are asking Congress to pass commonsense gun laws that strengthen background checks and keep our communities safe.",
  "id" : 748621170015076352,
  "in_reply_to_status_id" : 748620897309757440,
  "created_at" : "2016-06-30 20:56:10 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748620582216884224",
  "geo" : { },
  "id_str" : "748620897309757440",
  "in_reply_to_user_id" : 1536791610,
  "text" : "After more than 100 days, the Supreme Court still needs its 9th judge, but the Senate GOP refuses to do its job and consider Judge Garland.",
  "id" : 748620897309757440,
  "in_reply_to_status_id" : 748620582216884224,
  "created_at" : "2016-06-30 20:55:05 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748620388175798272",
  "geo" : { },
  "id_str" : "748620582216884224",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Congress is leaving a hefty to-do list undone. Health officials still need emergency funding to effectively protect Americans from Zika.",
  "id" : 748620582216884224,
  "in_reply_to_status_id" : 748620388175798272,
  "created_at" : "2016-06-30 20:53:50 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748620388175798272",
  "text" : "Proud to sign laws to improve transparency and avert a crisis in Puerto Rico. I'd hoped to use my pen more often before Congress left town.",
  "id" : 748620388175798272,
  "created_at" : "2016-06-30 20:53:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/T10g64niul",
      "expanded_url" : "https:\/\/twitter.com\/JustinTrudeau\/status\/748313331673501696",
      "display_url" : "twitter.com\/JustinTrudeau\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748541124524929024",
  "text" : "Until next time, Justin. Good to know that Canada and the world will benefit from your leadership for years to come. https:\/\/t.co\/T10g64niul",
  "id" : 748541124524929024,
  "created_at" : "2016-06-30 15:38:05 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "747466445345349632",
  "geo" : { },
  "id_str" : "747466642725056512",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Women\u2019s opportunities are expanded and our nation is stronger when all of our citizens have accessible, affordable health care.",
  "id" : 747466642725056512,
  "in_reply_to_status_id" : 747466445345349632,
  "created_at" : "2016-06-27 16:28:29 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747466445345349632",
  "text" : "Every woman has a constitutional right to make her own reproductive choices. I'm pleased to see the Supreme Court reaffirm that fact today.",
  "id" : 747466445345349632,
  "created_at" : "2016-06-27 16:27:42 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/vctfqAH5Wt",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745631702186336256",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745674203286773761",
  "text" : "Thank you John Lewis for leading on gun violence where we need it most. https:\/\/t.co\/vctfqAH5Wt",
  "id" : 745674203286773761,
  "created_at" : "2016-06-22 17:45:58 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745327295544569856",
  "text" : "By giving him its highest rating, the American Bar Association confirms what we all know: Judge Garland should serve on the Supreme Court.",
  "id" : 745327295544569856,
  "created_at" : "2016-06-21 18:47:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745272915780743168",
  "text" : "Gun violence requires more than moments of silence. It requires action. In failing that test, the Senate failed the American people.",
  "id" : 745272915780743168,
  "created_at" : "2016-06-21 15:11:24 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 38, 43 ],
      "id_str" : "19263978",
      "id" : 19263978
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 58, 68 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744734234179477504",
  "text" : "What a game and what a series for the @Cavs. Happy to see @KingJames bring it home for Cleveland!",
  "id" : 744734234179477504,
  "created_at" : "2016-06-20 03:30:52 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/SaNJgmoIK1",
      "expanded_url" : "https:\/\/twitter.com\/flotus\/status\/744547424757223425",
      "display_url" : "twitter.com\/flotus\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744656711596773380",
  "text" : "Happy Father's Day to all the dads out there. Glad to be spending this one with my family in Yosemite. https:\/\/t.co\/SaNJgmoIK1",
  "id" : 744656711596773380,
  "created_at" : "2016-06-19 22:22:49 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/kMuWTuXTdb",
      "expanded_url" : "http:\/\/www.theunitedstateofwomen.org",
      "display_url" : "theunitedstateofwomen.org"
    } ]
  },
  "geo" : { },
  "id_str" : "739817582514016256",
  "text" : "RT @FLOTUS: Together, we are stronger. Together we can change tomorrow. Stand with us: https:\/\/t.co\/kMuWTuXTdb #StateOfWomen\nhttps:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/kMuWTuXTdb",
        "expanded_url" : "http:\/\/www.theunitedstateofwomen.org",
        "display_url" : "theunitedstateofwomen.org"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/maBuf4nT0E",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/144d35e7-9e4c-4f5e-a0f6-6e352e434d17",
        "display_url" : "amp.twimg.com\/v\/144d35e7-9e4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739790326454312960",
    "text" : "Together, we are stronger. Together we can change tomorrow. Stand with us: https:\/\/t.co\/kMuWTuXTdb #StateOfWomen\nhttps:\/\/t.co\/maBuf4nT0E",
    "id" : 739790326454312960,
    "created_at" : "2016-06-06 12:05:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 739817582514016256,
  "created_at" : "2016-06-06 13:53:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/739095745584844800\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/z1yM3sSLH3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
      "id_str" : "739095700059922432",
      "id" : 739095700059922432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      } ],
      "display_url" : "pic.twitter.com\/z1yM3sSLH3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739095745584844800",
  "text" : "He shook up the world, and the world's better for it. Rest in peace, Champ. https:\/\/t.co\/z1yM3sSLH3",
  "id" : 739095745584844800,
  "created_at" : "2016-06-04 14:05:32 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WearOrange",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738388734207512578",
  "text" : "We cannot accept our level of gun violence as the new normal. We must take action to prevent this from happening again &amp; again. #WearOrange",
  "id" : 738388734207512578,
  "created_at" : "2016-06-02 15:16:07 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]