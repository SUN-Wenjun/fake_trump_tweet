Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/638403631306248192\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WyzQImKymX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwQuCvWEAAlThQ.jpg",
      "id_str" : "638403630375243776",
      "id" : 638403630375243776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwQuCvWEAAlThQ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WyzQImKymX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638403631306248192",
  "text" : "Today we\u2019re returning Mount McKinley to its native name - Denali, a step to reflect the heritage of Alaska Natives. http:\/\/t.co\/WyzQImKymX",
  "id" : 638403631306248192,
  "created_at" : "2015-08-31 17:31:01 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/637733790090199040\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/LDqsARhnZt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmvfxTVEAQRZLx.jpg",
      "id_str" : "637733782594850820",
      "id" : 637733782594850820,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmvfxTVEAQRZLx.jpg",
      "sizes" : [ {
        "h" : 687,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LDqsARhnZt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637733790090199040",
  "text" : "In Treme, I was inspired by the progress &amp; people 10 years after Katrina. It gives us hope, but our work isn't done. http:\/\/t.co\/LDqsARhnZt",
  "id" : 637733790090199040,
  "created_at" : "2015-08-29 21:09:18 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636923084818259968",
  "text" : "Amidst global volatility, Congress should protect the momentum of our growing economy (not kill it). We must avoid shutdown \/ austerity.",
  "id" : 636923084818259968,
  "created_at" : "2015-08-27 15:27:51 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/636235501658222592\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/R8RyB9vkVW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNRc0Q1U8AI3-ew.jpg",
      "id_str" : "636235500307673090",
      "id" : 636235500307673090,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNRc0Q1U8AI3-ew.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/R8RyB9vkVW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636235501658222592",
  "text" : "The National Park Service: 99 years and 84 million acres strong. Congrats to all who work to protect these treasures. http:\/\/t.co\/R8RyB9vkVW",
  "id" : 636235501658222592,
  "created_at" : "2015-08-25 17:55:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634413305516412928",
  "text" : "President Carter is as good a man as they come. Michelle and I are praying for him and Rosalynn. We're all pulling for you, Jimmy.",
  "id" : 634413305516412928,
  "created_at" : "2015-08-20 17:14:53 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/uer5sIl4Vk",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist1",
      "display_url" : "spoti.fi\/potusplaylist1"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/zHEekHvQBr",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist2",
      "display_url" : "spoti.fi\/potusplaylist2"
    } ]
  },
  "geo" : { },
  "id_str" : "632212730209009664",
  "text" : "Due to popular request, here are my vacation playlists: http:\/\/t.co\/uer5sIl4Vk http:\/\/t.co\/zHEekHvQBr What's your favorite summer song?",
  "id" : 632212730209009664,
  "created_at" : "2015-08-14 15:30:35 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 57, 67 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Havana",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "SecState",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "Cuba",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632209808930828288",
  "text" : "RT @JohnKerry: Pleased to be in #Havana for historic day @USEmbCuba. Incredible: last time #SecState visited #Cuba, FDR was @POTUS. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 42, 52 ],
        "id_str" : "133769083",
        "id" : 133769083
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 109, 115 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/632205031740153856\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/URedAaDpZs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYLIGAWgAAb3JW.jpg",
        "id_str" : "632205031371079680",
        "id" : 632205031371079680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYLIGAWgAAb3JW.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/URedAaDpZs"
      } ],
      "hashtags" : [ {
        "text" : "Havana",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "SecState",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "Cuba",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632205031740153856",
    "text" : "Pleased to be in #Havana for historic day @USEmbCuba. Incredible: last time #SecState visited #Cuba, FDR was @POTUS. http:\/\/t.co\/URedAaDpZs",
    "id" : 632205031740153856,
    "created_at" : "2015-08-14 15:00:00 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 632209808930828288,
  "created_at" : "2015-08-14 15:18:58 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ge74wu5nc1",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/629343428925636609",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629343799299411969",
  "text" : "Thank you for all you've done to protect our sacred right to vote. It's as important today as it's ever been. https:\/\/t.co\/ge74wu5nc1",
  "id" : 629343799299411969,
  "created_at" : "2015-08-06 17:30:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 12, 25 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/629342681962049538\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/L7kxtWQlYW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvf0AIXAAAiLNM.jpg",
      "id_str" : "629342657429569536",
      "id" : 629342657429569536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvf0AIXAAAiLNM.jpg",
      "sizes" : [ {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L7kxtWQlYW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629342056876503040",
  "geo" : { },
  "id_str" : "629342681962049538",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Heroes like @RepJohnLewis, Dr. King, and countless others sacrificed so that all of our voices could be heard. http:\/\/t.co\/L7kxtWQlYW",
  "id" : 629342681962049538,
  "in_reply_to_status_id" : 629342056876503040,
  "created_at" : "2015-08-06 17:26:02 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629341526439653377",
  "geo" : { },
  "id_str" : "629342056876503040",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Before 1965, African Americans faced poll taxes, literacy tests, or having to count jellybeans in a jar when they tried to register to vote.",
  "id" : 629342056876503040,
  "in_reply_to_status_id" : 629341526439653377,
  "created_at" : "2015-08-06 17:23:33 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629341526439653377",
  "text" : "50 years ago today, President Johnson signed the Voting Rights Act into law, securing the right to vote for millions of African Americans.",
  "id" : 629341526439653377,
  "created_at" : "2015-08-06 17:21:27 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 77, 82 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/629064761188184064\/video\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JKep9bcxGQ",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/629064721891766272\/pu\/img\/JVUKrM9Uo3LvGCSN.jpg",
      "id_str" : "629064721891766272",
      "id" : 629064721891766272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/629064721891766272\/pu\/img\/JVUKrM9Uo3LvGCSN.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JKep9bcxGQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629064761188184064",
  "text" : "Pretty incredible time lapse of the dark side of the moon passing Earth from @NASA. American ingenuity at work! http:\/\/t.co\/JKep9bcxGQ",
  "id" : 629064761188184064,
  "created_at" : "2015-08-05 23:01:41 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/UO0B5xCOPh",
      "expanded_url" : "https:\/\/twitter.com\/stevescalise\/status\/628971521663475712",
      "display_url" : "twitter.com\/stevescalise\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629030795299147776",
  "text" : "Important detail \u2013 there are no secret deals. My staff can brief you on any question about any part of the deal. https:\/\/t.co\/UO0B5xCOPh",
  "id" : 629030795299147776,
  "created_at" : "2015-08-05 20:46:43 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/nvBeO1Omko",
      "expanded_url" : "https:\/\/twitter.com\/senatemajldr\/status\/628946892236451840",
      "display_url" : "twitter.com\/senatemajldr\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629030461449338881",
  "text" : "The choice is ultimately between diplomacy and war. Iran's nuclear program accelerates if Congress kills this deal. https:\/\/t.co\/nvBeO1Omko",
  "id" : 629030461449338881,
  "created_at" : "2015-08-05 20:45:23 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/la7GhQXfzl",
      "expanded_url" : "https:\/\/twitter.com\/angelakkmiller\/status\/628944989406556160",
      "display_url" : "twitter.com\/angelakkmiller\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629028301454094336",
  "text" : "It's the strongest nuclear deal ever negotiated. There's no such thing as a \"better deal.\" Walking away risks war. https:\/\/t.co\/la7GhQXfzl",
  "id" : 629028301454094336,
  "created_at" : "2015-08-05 20:36:48 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628285077970153472",
  "geo" : { },
  "id_str" : "628286472781754368",
  "in_reply_to_user_id" : 1536791610,
  "text" : "I refuse to condemn our kids to a planet that's beyond fixing. Let's meet this challenge and #ActOnClimate together.",
  "id" : 628286472781754368,
  "in_reply_to_status_id" : 628285077970153472,
  "created_at" : "2015-08-03 19:29:02 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628283831104237569",
  "geo" : { },
  "id_str" : "628285077970153472",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Despite what the critics will tell you, this plan will ultimately save the average American family nearly $85 a year on their energy bills.",
  "id" : 628285077970153472,
  "in_reply_to_status_id" : 628283831104237569,
  "created_at" : "2015-08-03 19:23:30 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628283044772868097",
  "geo" : { },
  "id_str" : "628283831104237569",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Thanks to this plan, there will be 90,000 fewer asthma attacks among our kids and we'll avoid 3,600 premature deaths in 2030.",
  "id" : 628283831104237569,
  "in_reply_to_status_id" : 628283044772868097,
  "created_at" : "2015-08-03 19:18:32 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628282174869999616",
  "geo" : { },
  "id_str" : "628283044772868097",
  "in_reply_to_user_id" : 1536791610,
  "text" : "It's time to change that. With the Clean Power Plan, by 2030, carbon pollution from power plants will be 32% lower than it was a decade ago.",
  "id" : 628283044772868097,
  "in_reply_to_status_id" : 628282174869999616,
  "created_at" : "2015-08-03 19:15:25 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628280902817304578",
  "geo" : { },
  "id_str" : "628282174869999616",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Right now, power plants account for about one-third of America\u2019s carbon pollution. That\u2019s more than our cars, airplanes, and homes combined.",
  "id" : 628282174869999616,
  "in_reply_to_status_id" : 628280902817304578,
  "created_at" : "2015-08-03 19:11:58 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628280710017720321",
  "geo" : { },
  "id_str" : "628280902817304578",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Levels of carbon dioxide in our atmosphere are higher than they\u2019ve been in 800,000 years. 2014 was the planet\u2019s warmest year on record.",
  "id" : 628280902817304578,
  "in_reply_to_status_id" : 628280710017720321,
  "created_at" : "2015-08-03 19:06:54 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628280710017720321",
  "text" : "Today, we're announcing America's Clean Power Plan\u2014the most important step we've ever taken to combat climate change. Here are the facts:",
  "id" : 628280710017720321,
  "created_at" : "2015-08-03 19:06:08 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 4, 20 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627560699347255297",
  "text" : "Hey @StationCDRKelly, loving the photos. Do you ever look out the window and just freak out?",
  "id" : 627560699347255297,
  "created_at" : "2015-08-01 19:25:04 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]