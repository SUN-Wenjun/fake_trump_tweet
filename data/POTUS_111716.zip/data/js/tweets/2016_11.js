Grailbird.data.tweets_2016_11 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797128959578271744",
  "text" : "Today, we honor those who honored our country with its highest form of service. We owe our veterans our thanks, our respect and our freedom.",
  "id" : 797128959578271744,
  "created_at" : "2016-11-11 17:28:48 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796018814072672256",
  "text" : "Today, progress is on the ballot. Go vote - then make sure your friends, your family, and everyone you know votes too.",
  "id" : 796018814072672256,
  "created_at" : "2016-11-08 15:57:29 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/794322003754790913\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ZBQdNz8s80",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
      "id_str" : "794299143942344704",
      "id" : 794299143942344704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 1433
      } ],
      "display_url" : "pic.twitter.com\/ZBQdNz8s80"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/PJ7xIKP3Vo",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "794322003754790913",
  "text" : "It's pretty simple: Find a plan, get covered, earn some peace of mind. Start today: https:\/\/t.co\/PJ7xIKP3Vo https:\/\/t.co\/ZBQdNz8s80",
  "id" : 794322003754790913,
  "created_at" : "2016-11-03 23:34:58 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 13, 18 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794057504871346176",
  "text" : "It happened: @Cubs win World Series. That's change even this South Sider can believe in. Want to come to the White House before I leave?",
  "id" : 794057504871346176,
  "created_at" : "2016-11-03 06:03:56 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]