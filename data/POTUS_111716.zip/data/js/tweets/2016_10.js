Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 23, 28 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlyTheW",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790236602584948736",
  "text" : "I'll say it: Holy Cow, @Cubs fans. Even this White Sox fan was happy to see Wrigley rocking last night. #FlyTheW",
  "id" : 790236602584948736,
  "created_at" : "2016-10-23 17:01:02 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/789598150541635588\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/qe7h3IfTTZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvU3ODPUsAAdrIT.jpg",
      "id_str" : "789598024200663040",
      "id" : 789598024200663040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvU3ODPUsAAdrIT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qe7h3IfTTZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789598150541635588",
  "text" : "Check out my newest science advisors! These kids are fearless in using science to tackle our toughest problems. Thanks for the inspiration. https:\/\/t.co\/qe7h3IfTTZ",
  "id" : 789598150541635588,
  "created_at" : "2016-10-21 22:44:03 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789265672404627456",
  "text" : "RT @vj44: We lit the @WhiteHouse pink tonight to commemorate Breast Cancer Awareness Month. Make sure to enroll in #ACA starting Nov. 1 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/789237393719255044\/photo\/1",
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/RGc3N8ZkRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPvOOdWAAAVM4p.jpg",
        "id_str" : "789237387398348800",
        "id" : 789237387398348800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPvOOdWAAAVM4p.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/RGc3N8ZkRb"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 105, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789237393719255044",
    "text" : "We lit the @WhiteHouse pink tonight to commemorate Breast Cancer Awareness Month. Make sure to enroll in #ACA starting Nov. 1 https:\/\/t.co\/RGc3N8ZkRb",
    "id" : 789237393719255044,
    "created_at" : "2016-10-20 22:50:32 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789265672404627456,
  "created_at" : "2016-10-21 00:42:54 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 37, 52 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789096632537055232",
  "text" : "Outstanding 3 for 3 debate sweep for @HillaryClinton! Nobody has ever been more prepared to be @POTUS.",
  "id" : 789096632537055232,
  "created_at" : "2016-10-20 13:31:12 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/O0twPYcRSc",
      "expanded_url" : "https:\/\/twitter.com\/vp\/status\/788097252522721280",
      "display_url" : "twitter.com\/vp\/status\/7880\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788098889140219904",
  "text" : "For the loved ones we've lost and the ones we can still save, thank you Joe for putting us on the path to ending cancer as we know it. https:\/\/t.co\/O0twPYcRSc",
  "id" : 788098889140219904,
  "created_at" : "2016-10-17 19:26:31 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "100YearsStrong",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787662124197830656",
  "text" : "For a century, Planned Parenthood has made it possible for women to determine their own lives. Here's to another #100YearsStrong.",
  "id" : 787662124197830656,
  "created_at" : "2016-10-16 14:30:59 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9PRZB451fS",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "787047018606784512",
  "text" : "Clearly, we still have more to do to prevent sexual assault and the thinking that leads to it. That starts with us: https:\/\/t.co\/9PRZB451fS",
  "id" : 787047018606784512,
  "created_at" : "2016-10-14 21:46:46 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/c9cnANWPCS",
      "expanded_url" : "http:\/\/spoti.fi\/25fTuWt",
      "display_url" : "spoti.fi\/25fTuWt"
    } ]
  },
  "geo" : { },
  "id_str" : "786598777482153988",
  "text" : "Congratulations to one of my favorite poets, Bob Dylan, on a well-deserved Nobel. https:\/\/t.co\/c9cnANWPCS",
  "id" : 786598777482153988,
  "created_at" : "2016-10-13 16:05:37 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/WWBUm5eJ08",
      "expanded_url" : "https:\/\/twitter.com\/wired\/status\/786159612940656641",
      "display_url" : "twitter.com\/wired\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786254141182074880",
  "text" : "Now this was fun. Artificial intelligence, space travel\u2014hope you enjoy exploring new frontiers as much as I did. https:\/\/t.co\/WWBUm5eJ08",
  "id" : 786254141182074880,
  "created_at" : "2016-10-12 17:16:09 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayoftheGirl",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785887247727857664",
  "text" : "On International #DayoftheGirl, we remain committed to providing what we all want for our daughters: a future of limitless possibility.",
  "id" : 785887247727857664,
  "created_at" : "2016-10-11 16:58:15 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 55, 70 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785511825395765248",
  "text" : "Just like Michelle says, when they go low, we go high. @HillaryClinton went high and showed why she'll be a POTUS for all Americans.",
  "id" : 785511825395765248,
  "created_at" : "2016-10-10 16:06:27 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/784508784316063744\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/NMesNhwsaG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuMikhCUMAAfJl0.jpg",
      "id_str" : "784508770831314944",
      "id" : 784508770831314944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuMikhCUMAAfJl0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/NMesNhwsaG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/SUUmUADsHj",
      "expanded_url" : "http:\/\/Vote.gov",
      "display_url" : "Vote.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "784508784316063744",
  "text" : "Voted early today. Make sure you vote too: https:\/\/t.co\/SUUmUADsHj https:\/\/t.co\/NMesNhwsaG",
  "id" : 784508784316063744,
  "created_at" : "2016-10-07 21:40:44 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Vaf8Xubs0s",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "784170804279992320",
  "text" : "Hurricane Matthew is as serious as it gets. Listen to local officials, prepare, take care of each other. https:\/\/t.co\/Vaf8Xubs0s",
  "id" : 784170804279992320,
  "created_at" : "2016-10-06 23:17:43 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783771904297447424",
  "text" : "Thank you to every nation that moved to bring the Paris Agreement into force. History will judge today as a turning point for our planet.",
  "id" : 783771904297447424,
  "created_at" : "2016-10-05 20:52:38 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/782970909229326336\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/nTb10I3GHP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
      "id_str" : "782970546363346944",
      "id" : 782970546363346944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1037,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1769,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2812,
        "resize" : "fit",
        "w" : 3255
      } ],
      "display_url" : "pic.twitter.com\/nTb10I3GHP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/qCXwVI0uLH",
      "expanded_url" : "http:\/\/wh.gov\/SXSL",
      "display_url" : "wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "782970909229326336",
  "text" : "Bringing a little Austin to the South Lawn today. https:\/\/t.co\/qCXwVI0uLH https:\/\/t.co\/nTb10I3GHP",
  "id" : 782970909229326336,
  "created_at" : "2016-10-03 15:49:46 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RyderCup",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782762238616727552",
  "text" : "What a win by the USA in #RyderCup. Proud to see our guys bring the trophy back home. Arnie is smiling down.",
  "id" : 782762238616727552,
  "created_at" : "2016-10-03 02:00:35 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "indices" : [ 85, 98 ],
      "id_str" : "18839785",
      "id" : 18839785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782594690738597888",
  "text" : "Gandhiji believed in a world worthy of our children. In joining the Paris Agreement, @narendramodi &amp; the Indian people carry on that legacy.",
  "id" : 782594690738597888,
  "created_at" : "2016-10-02 14:54:48 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/OPeQiVPJlK",
      "expanded_url" : "http:\/\/nyti.ms\/2cIsldp",
      "display_url" : "nyti.ms\/2cIsldp"
    } ]
  },
  "geo" : { },
  "id_str" : "782218662228942848",
  "text" : "Paid leave shouldn't be a luxury. It's a basic necessity that we should secure for every working American. https:\/\/t.co\/OPeQiVPJlK",
  "id" : 782218662228942848,
  "created_at" : "2016-10-01 14:00:36 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]