Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Benstead",
      "screen_name" : "JustineinTampa",
      "indices" : [ 3, 18 ],
      "id_str" : "165211956",
      "id" : 165211956
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604024846574620674",
  "text" : "RT @JustineinTampa: @POTUS I'm 30 now, but I've been promoting climate change since I was in the third grade! #ActOnClimate http:\/\/t.co\/d77\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JustineinTampa\/status\/604007518541606913\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/d77QhJVm2f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGHdoGHVAAAXNYV.jpg",
        "id_str" : "604007505950212096",
        "id" : 604007505950212096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGHdoGHVAAAXNYV.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/d77QhJVm2f"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603976385044971520",
    "geo" : { },
    "id_str" : "604007518541606913",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS I'm 30 now, but I've been promoting climate change since I was in the third grade! #ActOnClimate http:\/\/t.co\/d77QhJVm2f",
    "id" : 604007518541606913,
    "in_reply_to_status_id" : 603976385044971520,
    "created_at" : "2015-05-28 19:33:08 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Justine Benstead",
      "screen_name" : "JustineinTampa",
      "protected" : false,
      "id_str" : "165211956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621392269237727233\/FzQki0eC_normal.jpg",
      "id" : 165211956,
      "verified" : false
    }
  },
  "id" : 604024846574620674,
  "created_at" : "2015-05-28 20:42:00 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Hadly",
      "screen_name" : "LizHadly",
      "indices" : [ 3, 12 ],
      "id_str" : "322658873",
      "id" : 322658873
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    }, {
      "text" : "WeKnowEnoughToAct",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604024486036393984",
  "text" : "RT @LizHadly: @POTUS Love the #ActOnClimate. As scientist, I say global action more important than science now. #WeKnowEnoughToAct.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 16, 29 ]
      }, {
        "text" : "WeKnowEnoughToAct",
        "indices" : [ 98, 116 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603976385044971520",
    "geo" : { },
    "id_str" : "604000694580965377",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS Love the #ActOnClimate. As scientist, I say global action more important than science now. #WeKnowEnoughToAct.",
    "id" : 604000694580965377,
    "in_reply_to_status_id" : 603976385044971520,
    "created_at" : "2015-05-28 19:06:02 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Elizabeth Hadly",
      "screen_name" : "LizHadly",
      "protected" : false,
      "id_str" : "322658873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1540226252\/liz_photo_small_normal.jpg",
      "id" : 322658873,
      "verified" : false
    }
  },
  "id" : 604024486036393984,
  "created_at" : "2015-05-28 20:40:34 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603976385044971520",
  "text" : "Thanks for the questions! This was fun. I've got to run, but let\u2019s do it again soon. Tell me what you're doing to #ActOnClimate.",
  "id" : 603976385044971520,
  "created_at" : "2015-05-28 17:29:26 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshar Patel",
      "screen_name" : "apat246",
      "indices" : [ 1, 9 ],
      "id_str" : "390825318",
      "id" : 390825318
    }, {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 10, 23 ],
      "id_str" : "16212685",
      "id" : 16212685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603962271732215808",
  "geo" : { },
  "id_str" : "603976299246321664",
  "in_reply_to_user_id" : 390825318,
  "text" : ".@apat246 @chicagobulls love thibs and think he did a great job. Sorry to see him go but expect he will be snatched up soon by another team.",
  "id" : 603976299246321664,
  "in_reply_to_status_id" : 603962271732215808,
  "created_at" : "2015-05-28 17:29:05 +0000",
  "in_reply_to_screen_name" : "apat246",
  "in_reply_to_user_id_str" : "390825318",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 1, 12 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603968816289292289",
  "geo" : { },
  "id_str" : "603975856466198528",
  "in_reply_to_user_id" : 1322284950,
  "text" : ".@ZCarlander agreement with China big and will be working w Brazil to develop their plans. We will all need to do more with US leading",
  "id" : 603975856466198528,
  "in_reply_to_status_id" : 603968816289292289,
  "created_at" : "2015-05-28 17:27:20 +0000",
  "in_reply_to_screen_name" : "ZCarlander",
  "in_reply_to_user_id_str" : "1322284950",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariana Stover",
      "screen_name" : "arianastover",
      "indices" : [ 1, 14 ],
      "id_str" : "37115355",
      "id" : 37115355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603960787011543040",
  "geo" : { },
  "id_str" : "603975267422380033",
  "in_reply_to_user_id" : 37115355,
  "text" : ".@arianastover Kids instinctively understand importance of environment, impact on animals, health. Weave it into science and social studies",
  "id" : 603975267422380033,
  "in_reply_to_status_id" : 603960787011543040,
  "created_at" : "2015-05-28 17:24:59 +0000",
  "in_reply_to_screen_name" : "arianastover",
  "in_reply_to_user_id_str" : "37115355",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Htet Wint",
      "screen_name" : "HtetWint",
      "indices" : [ 1, 10 ],
      "id_str" : "629103290",
      "id" : 629103290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603972023216312321",
  "geo" : { },
  "id_str" : "603974634510233600",
  "in_reply_to_user_id" : 629103290,
  "text" : ".@HtetWint renewable energy key, already increased solar 10x and wind 3x, now need to invest more in r&amp;d and provide regulatory incentives",
  "id" : 603974634510233600,
  "in_reply_to_status_id" : 603972023216312321,
  "created_at" : "2015-05-28 17:22:28 +0000",
  "in_reply_to_screen_name" : "HtetWint",
  "in_reply_to_user_id_str" : "629103290",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L.",
      "screen_name" : "jamesthe4tress",
      "indices" : [ 2, 17 ],
      "id_str" : "312459288",
      "id" : 312459288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603961385710526464",
  "geo" : { },
  "id_str" : "603973676975939585",
  "in_reply_to_user_id" : 312459288,
  "text" : ". @Jamesthe4tress Already expanded Pell Grants and capped student loan interest rates; now want to make 2 yrs of community college free.",
  "id" : 603973676975939585,
  "in_reply_to_status_id" : 603961385710526464,
  "created_at" : "2015-05-28 17:18:40 +0000",
  "in_reply_to_screen_name" : "jamesthe4tress",
  "in_reply_to_user_id_str" : "312459288",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory D.",
      "screen_name" : "HLF3267",
      "indices" : [ 0, 8 ],
      "id_str" : "2295625259",
      "id" : 2295625259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603961258912653314",
  "geo" : { },
  "id_str" : "603973127383580672",
  "in_reply_to_user_id" : 2295625259,
  "text" : "@HLF3267 In fact new trade deal with have the strongest enforceable environmental provisions in history, raising standards across Asia.",
  "id" : 603973127383580672,
  "in_reply_to_status_id" : 603961258912653314,
  "created_at" : "2015-05-28 17:16:29 +0000",
  "in_reply_to_screen_name" : "HLF3267",
  "in_reply_to_user_id_str" : "2295625259",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 1, 12 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603960838026821634",
  "geo" : { },
  "id_str" : "603972926287708160",
  "in_reply_to_user_id" : 1322284950,
  "text" : ".@ZCarlander more severe weather events lead to displacement, scarcity, stressed populations; all increase likelihood of global conflict.",
  "id" : 603972926287708160,
  "in_reply_to_status_id" : 603960838026821634,
  "created_at" : "2015-05-28 17:15:41 +0000",
  "in_reply_to_screen_name" : "ZCarlander",
  "in_reply_to_user_id_str" : "1322284950",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathen Vieira",
      "screen_name" : "NathenVieira",
      "indices" : [ 1, 14 ],
      "id_str" : "162090984",
      "id" : 162090984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603960256067194880",
  "geo" : { },
  "id_str" : "603971948180176896",
  "in_reply_to_user_id" : 162090984,
  "text" : ".@NathenVieira jr smith having a great season but the heart of the Cavs is Lebron. And no one can outshoot Curry - maybe Korver if wide open",
  "id" : 603971948180176896,
  "in_reply_to_status_id" : 603960256067194880,
  "created_at" : "2015-05-28 17:11:48 +0000",
  "in_reply_to_screen_name" : "NathenVieira",
  "in_reply_to_user_id_str" : "162090984",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603971215372361728",
  "text" : "@.gkermmm 2\/ after I sign agreement, Congress will have months of debate before a vote. Nothing secret about it.",
  "id" : 603971215372361728,
  "created_at" : "2015-05-28 17:08:53 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Kermec",
      "screen_name" : "gkermmm",
      "indices" : [ 1, 9 ],
      "id_str" : "465076617",
      "id" : 465076617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959975652691968",
  "geo" : { },
  "id_str" : "603971008328957953",
  "in_reply_to_user_id" : 465076617,
  "text" : ".@gkermmm 1\/ TPP is still being negotiated! But legislation requires the full text for 60 days before I sign.",
  "id" : 603971008328957953,
  "in_reply_to_status_id" : 603959975652691968,
  "created_at" : "2015-05-28 17:08:04 +0000",
  "in_reply_to_screen_name" : "gkermmm",
  "in_reply_to_user_id_str" : "465076617",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derrick Neuner",
      "screen_name" : "drock89",
      "indices" : [ 1, 9 ],
      "id_str" : "28640463",
      "id" : 28640463
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 13, 22 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959452337770497",
  "geo" : { },
  "id_str" : "603970422636290048",
  "in_reply_to_user_id" : 28640463,
  "text" : ".@drock89 as @Pontifex and other religious leaders have stated we have a moral obligation to the most vulnerable and the next generation.",
  "id" : 603970422636290048,
  "in_reply_to_status_id" : 603959452337770497,
  "created_at" : "2015-05-28 17:05:44 +0000",
  "in_reply_to_screen_name" : "drock89",
  "in_reply_to_user_id_str" : "28640463",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 1, 12 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959664385064961",
  "geo" : { },
  "id_str" : "603969986730708992",
  "in_reply_to_user_id" : 1007173664,
  "text" : ".@BigBennyFL 3\/ already rejected Shell's original proposal as inadequate which shows we're serious.",
  "id" : 603969986730708992,
  "in_reply_to_status_id" : 603959664385064961,
  "created_at" : "2015-05-28 17:04:00 +0000",
  "in_reply_to_screen_name" : "BigBennyFL",
  "in_reply_to_user_id_str" : "1007173664",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 1, 12 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959664385064961",
  "geo" : { },
  "id_str" : "603969716261036032",
  "in_reply_to_user_id" : 1007173664,
  "text" : ".@BigBennyFL 2\/ But since we can't prevent oil exploration completely in region we're setting the highest possible standards",
  "id" : 603969716261036032,
  "in_reply_to_status_id" : 603959664385064961,
  "created_at" : "2015-05-28 17:02:56 +0000",
  "in_reply_to_screen_name" : "BigBennyFL",
  "in_reply_to_user_id_str" : "1007173664",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 0, 11 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959664385064961",
  "geo" : { },
  "id_str" : "603968878058676225",
  "in_reply_to_user_id" : 1007173664,
  "text" : "@BigBennyFL 1\/ We've shut off drilling in the most sensitive arctic areas, including Bristol Bay.",
  "id" : 603968878058676225,
  "in_reply_to_status_id" : 603959664385064961,
  "created_at" : "2015-05-28 16:59:36 +0000",
  "in_reply_to_screen_name" : "BigBennyFL",
  "in_reply_to_user_id_str" : "1007173664",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb",
      "screen_name" : "calebmegajew",
      "indices" : [ 1, 14 ],
      "id_str" : "360324412",
      "id" : 360324412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603959889497559040",
  "geo" : { },
  "id_str" : "603968065240313859",
  "in_reply_to_user_id" : 360324412,
  "text" : ".@calebmegajew the science is overwhelming but what will move Congress will be public opinion. Your voices will make them open to facts.",
  "id" : 603968065240313859,
  "in_reply_to_status_id" : 603959889497559040,
  "created_at" : "2015-05-28 16:56:22 +0000",
  "in_reply_to_screen_name" : "calebmegajew",
  "in_reply_to_user_id_str" : "360324412",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/603966058462973953\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/5KrIb5jL6S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
      "id_str" : "603965968537104384",
      "id" : 603965968537104384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5KrIb5jL6S"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603966058462973953",
  "text" : "Ready to answer your questions on climate change. Let's do this! #AskPOTUS http:\/\/t.co\/5KrIb5jL6S",
  "id" : 603966058462973953,
  "created_at" : "2015-05-28 16:48:24 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603959253334822913",
  "text" : "Just got a hurricane preparedness briefing in Miami. Acting on climate change is critical. Got climate Qs? I'll answer at 1pm ET. #AskPOTUS",
  "id" : 603959253334822913,
  "created_at" : "2015-05-28 16:21:21 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/602878130362146816\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hChhhOVCS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF3adi7WoAArHvU.jpg",
      "id_str" : "602878126264328192",
      "id" : 602878126264328192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF3adi7WoAArHvU.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hChhhOVCS3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602878130362146816",
  "text" : "Spent the morning at Arlington. Take time today to honor our fallen heroes. We're forever indebted to their families. http:\/\/t.co\/hChhhOVCS3",
  "id" : 602878130362146816,
  "created_at" : "2015-05-25 16:45:21 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Z",
      "screen_name" : "DrFahmida",
      "indices" : [ 1, 11 ],
      "id_str" : "211171360",
      "id" : 211171360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601808287529455616",
  "geo" : { },
  "id_str" : "601844801672257536",
  "in_reply_to_user_id" : 211171360,
  "text" : ".@DrFahmida tell your niece I really like her letter. Couldn't agree more!",
  "id" : 601844801672257536,
  "in_reply_to_status_id" : 601808287529455616,
  "created_at" : "2015-05-22 20:19:17 +0000",
  "in_reply_to_screen_name" : "DrFahmida",
  "in_reply_to_user_id_str" : "211171360",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rabbi Steven Wernick",
      "screen_name" : "rebsteve",
      "indices" : [ 1, 10 ],
      "id_str" : "43697249",
      "id" : 43697249
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/601841646020464640\/video\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/6b8CrXSgMt",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/601841156528418816\/pu\/img\/NOPCDy9EcMYKQ45J.jpg",
      "id_str" : "601841156528418816",
      "id" : 601841156528418816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/601841156528418816\/pu\/img\/NOPCDy9EcMYKQ45J.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6b8CrXSgMt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601770783443124224",
  "geo" : { },
  "id_str" : "601841646020464640",
  "in_reply_to_user_id" : 43697249,
  "text" : ".@rebsteve really enjoyed stopping by today. I had fun singing Shabbat Shalom with the PreK class downstairs, too! http:\/\/t.co\/6b8CrXSgMt",
  "id" : 601841646020464640,
  "in_reply_to_status_id" : 601770783443124224,
  "created_at" : "2015-05-22 20:06:44 +0000",
  "in_reply_to_screen_name" : "rebsteve",
  "in_reply_to_user_id_str" : "43697249",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/601082858497830913\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1z4fteA1YJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFd5oe-W8AAxM5Y.jpg",
      "id_str" : "601082811693592576",
      "id" : 601082811693592576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFd5oe-W8AAxM5Y.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1z4fteA1YJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601082858497830913",
  "text" : "An honor to address the Coast Guard class of 2015. Confident they'll help us meet big challenges like climate change. http:\/\/t.co\/1z4fteA1YJ",
  "id" : 601082858497830913,
  "created_at" : "2015-05-20 17:51:35 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 15, 27 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 88, 95 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600389785769881600",
  "geo" : { },
  "id_str" : "600407380279566336",
  "in_reply_to_user_id" : 1330457336,
  "text" : "Good question, @billclinton. The handle comes with the house. Know anyone interested in @FLOTUS?",
  "id" : 600407380279566336,
  "in_reply_to_status_id" : 600389785769881600,
  "created_at" : "2015-05-18 21:07:29 +0000",
  "in_reply_to_screen_name" : "billclinton",
  "in_reply_to_user_id_str" : "1330457336",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/600388258665787392\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/3MiWk43c8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
      "id_str" : "600388215237808128",
      "id" : 600388215237808128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3MiWk43c8g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600388258665787392",
  "text" : "In Camden today, seeing first-hand how smart policing is making the community safer while building trust. http:\/\/t.co\/3MiWk43c8g",
  "id" : 600388258665787392,
  "created_at" : "2015-05-18 19:51:30 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600324682190053376",
  "text" : "Hello, Twitter! It's Barack. Really! Six years in, they're finally giving me my own account.",
  "id" : 600324682190053376,
  "created_at" : "2015-05-18 15:38:52 +0000",
  "user" : {
    "name" : "President Obama",
    "screen_name" : "POTUS",
    "protected" : false,
    "id_str" : "1536791610",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
    "id" : 1536791610,
    "verified" : true
  }
} ]